window._config = {
    cognito: {
        userPoolId: 'us-east-1_Z7ofjiBqm',  
        userPoolClientId: '798ruv79h38ud6e95pfgq8a3oi',
       
        region: 'us-east-1'
    },
    api: {
        invokeUrl: 'https://r93uq6xdol.execute-api.us-east-1.amazonaws.com/devp' 
    }
};
